The code.p4 contains source code for a simple P4 forwarder switch, and the compiled BMV2 code can be found in the JSON file.

To use this on the tutorial topology, simply copy the code.json to:
/var/lib/docker/volumes/shared/_data

After running the install for the P4Docker tool, which will setup the Docker shared directory above.
